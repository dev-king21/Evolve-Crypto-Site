(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[27],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonFilled_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonFilled.vue */ "./resources/js/src/views/components/vuesax/button/ButtonFilled.vue");
/* harmony import */ var _ButtonBorder_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ButtonBorder.vue */ "./resources/js/src/views/components/vuesax/button/ButtonBorder.vue");
/* harmony import */ var _ButtonFlat_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ButtonFlat.vue */ "./resources/js/src/views/components/vuesax/button/ButtonFlat.vue");
/* harmony import */ var _ButtonLineDown_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ButtonLineDown.vue */ "./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue");
/* harmony import */ var _ButtonGradient_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ButtonGradient.vue */ "./resources/js/src/views/components/vuesax/button/ButtonGradient.vue");
/* harmony import */ var _ButtonRelief_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ButtonRelief.vue */ "./resources/js/src/views/components/vuesax/button/ButtonRelief.vue");
/* harmony import */ var _ButtonColor_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ButtonColor.vue */ "./resources/js/src/views/components/vuesax/button/ButtonColor.vue");
/* harmony import */ var _ButtonTextColor_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ButtonTextColor.vue */ "./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue");
/* harmony import */ var _ButtonIcon_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ButtonIcon.vue */ "./resources/js/src/views/components/vuesax/button/ButtonIcon.vue");
/* harmony import */ var _ButtonIconOnly_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ButtonIconOnly.vue */ "./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue");
/* harmony import */ var _ButtonSize_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ButtonSize.vue */ "./resources/js/src/views/components/vuesax/button/ButtonSize.vue");
/* harmony import */ var _ButtonRouter_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ButtonRouter.vue */ "./resources/js/src/views/components/vuesax/button/ButtonRouter.vue");
/* harmony import */ var _ButtonLink_vue__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ButtonLink.vue */ "./resources/js/src/views/components/vuesax/button/ButtonLink.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//













/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    ButtonFilled: _ButtonFilled_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    ButtonBorder: _ButtonBorder_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    ButtonFlat: _ButtonFlat_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    ButtonLineDown: _ButtonLineDown_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    ButtonGradient: _ButtonGradient_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    ButtonRelief: _ButtonRelief_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    ButtonColor: _ButtonColor_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    ButtonTextColor: _ButtonTextColor_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    ButtonIcon: _ButtonIcon_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    ButtonIconOnly: _ButtonIconOnly_vue__WEBPACK_IMPORTED_MODULE_9__["default"],
    ButtonSize: _ButtonSize_vue__WEBPACK_IMPORTED_MODULE_10__["default"],
    ButtonRouter: _ButtonRouter_vue__WEBPACK_IMPORTED_MODULE_11__["default"],
    ButtonLink: _ButtonLink_vue__WEBPACK_IMPORTED_MODULE_12__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      colorx: '#9ecc38',
      colorx2: '#3EC9D6'
    };
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=template&id=3c85a93a&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=template&id=3c85a93a& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "button-demo" } },
    [
      _c("button-filled"),
      _vm._v(" "),
      _c("button-border"),
      _vm._v(" "),
      _c("button-flat"),
      _vm._v(" "),
      _c("button-line-down"),
      _vm._v(" "),
      _c("button-gradient"),
      _vm._v(" "),
      _c("button-relief"),
      _vm._v(" "),
      _c("button-color"),
      _vm._v(" "),
      _c("button-text-color"),
      _vm._v(" "),
      _c("button-icon"),
      _vm._v(" "),
      _c("button-icon-only"),
      _vm._v(" "),
      _c("button-size"),
      _vm._v(" "),
      _c("button-router"),
      _vm._v(" "),
      _c("button-link")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonBorder.vue?vue&type=template&id=4f04816f&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonBorder.vue?vue&type=template&id=4f04816f& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Border", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To add a type of button with edges we change the value of "),
        _c("code", [_vm._v("border")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { color: "primary", type: "border" } }, [
            _vm._v("Primary")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "success", type: "border" } }, [
            _vm._v("Success")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "danger", type: "border" } }, [
            _vm._v("Danger")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "warning", type: "border" } }, [
            _vm._v("Warning")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "dark", type: "border" } }, [
            _vm._v("Dark")
          ]),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { color: "rgb(11, 189, 135)", type: "border" } },
            [_vm._v("RGB")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { disabled: "", type: "border" } }, [
            _vm._v("Disabled")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="border">Primary</vs-button>\n<vs-button color="success" type="border">Success</vs-button>\n<vs-button color="danger" type="border">Danger</vs-button>\n<vs-button color="warning" type="border">Warning</vs-button>\n<vs-button color="dark" type="border">Dark</vs-button>\n<vs-button color="rgb(11, 189, 135)" type="border">RGB</vs-button>\n<vs-button disabled type="border">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=template&id=437fe670&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=template&id=437fe670& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Color", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "There are cases in which we need something more personalized like a specific color, you can change the color of the button with the property "
        ),
        _c("code", [_vm._v("color")]),
        _vm._v(" giving it as a value the color")
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { icon: "warning", active: "true", color: "warning" }
        },
        [
          _c("span", [
            _vm._v("Only "),
            _c("strong", [_vm._v("RGB")]),
            _vm._v(" and "),
            _c("strong", [_vm._v("HEX")]),
            _vm._v(" colors are supported.")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("span", [
            _vm._v(
              "If you need a gradient type button, to assign the color you have to use the property "
            ),
            _c("code", [_vm._v("gradient-color-secondary")])
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.colorx,
                expression: "colorx"
              }
            ],
            attrs: { type: "color", name: "", value: "" },
            domProps: { value: _vm.colorx },
            on: {
              input: function($event) {
                if ($event.target.composing) {
                  return
                }
                _vm.colorx = $event.target.value
              }
            }
          }),
          _vm._v(" "),
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.colorx2,
                expression: "colorx2"
              }
            ],
            attrs: { type: "color", name: "", value: "" },
            domProps: { value: _vm.colorx2 },
            on: {
              input: function($event) {
                if ($event.target.composing) {
                  return
                }
                _vm.colorx2 = $event.target.value
              }
            }
          }),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: _vm.colorx, type: "filled" } }, [
            _vm._v("Color")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: _vm.colorx, type: "border" } }, [
            _vm._v("Color")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: _vm.colorx, type: "flat" } }, [
            _vm._v("Color")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: _vm.colorx, type: "line" } }, [
            _vm._v("Color")
          ]),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: _vm.colorx,
                "gradient-color-secondary": _vm.colorx2,
                type: "gradient"
              }
            },
            [_vm._v("Color")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: _vm.colorx, type: "relief" } }, [
            _vm._v("Color")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template lang="html">\n  <div class="">\n    <input type="color" v-model="colorx" name="" value="">\n    <input type="color" v-model="colorx2" name="" value="">\n    <vs-button :color="colorx" type="filled">Color</vs-button>\n    <vs-button :color="colorx" type="border">Color</vs-button>\n    <vs-button :color="colorx" type="flat">Color</vs-button>\n    <vs-button :color="colorx" type="line">Color</vs-button>\n    <vs-button :color="colorx" :gradient-color-secondary="colorx2" type="gradient">Color</vs-button>\n    <vs-button :color="colorx"  type="relief">Color</vs-button>\n  </div>\n</template>\n\n<script>\nexport default {\n  data(){\n    return {\n      colorx:\'#9ecc38\',\n      colorx2:\'#3EC9D6\'\n    }\n  },\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonFilled.vue?vue&type=template&id=4495a0b6&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonFilled.vue?vue&type=template&id=4495a0b6& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Filled", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To define the type of button the directive is used "),
        _c("code", [_vm._v("type")]),
        _vm._v(" with the value of some type of button like it can be: "),
        _c("code", [_vm._v("filled")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { color: "primary", type: "filled" } }, [
            _vm._v("Primary")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "success", type: "filled" } }, [
            _vm._v("Success")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "danger", type: "filled" } }, [
            _vm._v("Danger")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "warning", type: "filled" } }, [
            _vm._v("Warning")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "dark", type: "filled" } }, [
            _vm._v("Dark")
          ]),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { color: "rgb(62, 201, 214)", type: "filled" } },
            [_vm._v("RGB")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { disabled: "", type: "filled" } }, [
            _vm._v("Disabled")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="filled">Primary</vs-button>\n<vs-button color="success" type="filled">Success</vs-button>\n<vs-button color="danger" type="filled">Danger</vs-button>\n<vs-button color="warning" type="filled">Warning</vs-button>\n<vs-button color="dark" type="filled">Dark</vs-button>\n<vs-button color="rgb(62, 201, 214)" type="filled">RGB</vs-button>\n<vs-button disabled type="filled">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonFlat.vue?vue&type=template&id=acec6608&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonFlat.vue?vue&type=template&id=acec6608& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Flat", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To add a type of button with edges just change the prop "),
        _c("code", [_vm._v("type")]),
        _vm._v(" to "),
        _c("code", [_vm._v("flat")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { color: "primary", type: "flat" } }, [
            _vm._v("Primary")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "success", type: "flat" } }, [
            _vm._v("Success")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "danger", type: "flat" } }, [
            _vm._v("Danger")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "warning", type: "flat" } }, [
            _vm._v("Warning")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "dark", type: "flat" } }, [
            _vm._v("Dark")
          ]),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { color: "rgb(11, 189, 135)", type: "flat" } },
            [_vm._v("RGB")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { disabled: "", type: "flat" } }, [
            _vm._v("Disabled")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="flat">Primary</vs-button>\n<vs-button color="success" type="flat">Success</vs-button>\n<vs-button color="danger" type="flat">Danger</vs-button>\n<vs-button color="warning" type="flat">Warning</vs-button>\n<vs-button color="dark" type="flat">Dark</vs-button>\n<vs-button color="rgb(11, 189, 135)" type="flat">RGB</vs-button>\n<vs-button disabled type="flat">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonGradient.vue?vue&type=template&id=ae05389a&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonGradient.vue?vue&type=template&id=ae05389a& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Gradient", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To add a type of button with edges we change the value of "),
        _c("code", [_vm._v("type")]),
        _vm._v(" by: "),
        _c("code", [_vm._v("gradient")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { type: "gradient" } }, [_vm._v("Primary")]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "success", type: "gradient" } }, [
            _vm._v("Success")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "danger", type: "gradient" } }, [
            _vm._v("Danger")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "warning", type: "gradient" } }, [
            _vm._v("Warning")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "dark", type: "gradient" } }, [
            _vm._v("Dark")
          ]),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "#3dd495",
                "gradient-color-secondary": "rgb(130, 207, 23)",
                type: "gradient"
              }
            },
            [_vm._v("Dark")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { disabled: "", type: "gradient" } }, [
            _vm._v("Disabled")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button type="gradient">primary</vs-button>\n<vs-button color="success" type="gradient">success</vs-button>\n<vs-button color="danger" type="gradient">danger</vs-button>\n<vs-button color="warning" type="gradient">warning</vs-button>\n<vs-button color="dark" type="gradient">dark</vs-button>\n<vs-button color="#3dd495" gradient-color-secondary="rgb(130, 207, 23)" type="gradient">dark</vs-button>\n<vs-button disabled type="gradient">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonIcon.vue?vue&type=template&id=1ca489fc&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonIcon.vue?vue&type=template&id=1ca489fc& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Icon", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can add an icon to the button with the property "),
        _c("code", [_vm._v("icon")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("span", [
            _vm._v(
              "Vuesax uses the Google Material Icons font library by default. For a list of all available icons, visit the official "
            ),
            _c(
              "a",
              {
                attrs: { href: "https://material.io/icons/", target: "_blank" }
              },
              [_vm._v("Material Icons page")]
            ),
            _vm._v(
              ". Other icon libraries can be used by providing the class for the respective pack in the icon-pack property. ex. FA4 uses fa or fas, FA5 uses fas, far, or fal."
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5 mb-3",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("span", [
            _vm._v(
              "You can change the position of the icon so that it is after the text with the property "
            ),
            _c("code", [_vm._v("icon-after")])
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c(
            "vs-button",
            {
              attrs: {
                color: "primary",
                type: "border",
                "icon-pack": "feather",
                icon: "icon-home"
              }
            },
            [_vm._v("Home")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "warning",
                type: "filled",
                "icon-pack": "feather",
                icon: "icon-star"
              }
            },
            [_vm._v("Star")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "success",
                type: "flat",
                "icon-pack": "feather",
                icon: "icon-check"
              }
            },
            [_vm._v("Done")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "dark",
                type: "line",
                "icon-pack": "feather",
                icon: "icon-menu",
                "icon-after": ""
              }
            },
            [_vm._v("menu")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "danger",
                type: "gradient",
                "icon-pack": "feather",
                icon: "icon-heart",
                "icon-after": ""
              }
            },
            [_vm._v("favorite")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                disabled: "",
                color: "primary",
                type: "border",
                "icon-pack": "feather",
                icon: "icon-home"
              }
            },
            [_vm._v("Disabled")]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="border" icon-pack="feather" icon="icon-home">Home</vs-button>\n<vs-button color="warning" type="filled" icon-pack="feather" icon="icon-star">Star</vs-button>\n<vs-button color="success" type="flat" icon-pack="feather" icon="icon-check">Done</vs-button>\n<vs-button color="dark" type="line" icon-pack="feather" icon="icon-menu" icon-after>menu</vs-button>\n<vs-button color="danger" type="gradient" icon-pack="feather" icon="icon-heart" icon-after>favorite</vs-button>\n<vs-button disabled color="primary" type="border" icon-pack="feather" icon="icon-home">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue?vue&type=template&id=71c105c8&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue?vue&type=template&id=71c105c8& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Icon Only", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can have a button with only the icon you want with the property "
        ),
        _c("code", [_vm._v("icon")]),
        _vm._v(" and not add any internal value to the button")
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5 mb-3",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("span", [
            _vm._v(
              "You can use the radius property to determine the border-radius of the button, there are many cases in which we need it to be round for example."
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", {
            attrs: {
              color: "primary",
              type: "border",
              "icon-pack": "feather",
              icon: "icon-search"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              color: "warning",
              type: "filled",
              "icon-pack": "feather",
              icon: "icon-archive"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              color: "success",
              type: "flat",
              "icon-pack": "feather",
              icon: "icon-camera"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              color: "dark",
              type: "line",
              "icon-pack": "feather",
              icon: "icon-calendar"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              color: "danger",
              type: "gradient",
              "icon-pack": "feather",
              icon: "icon-user-plus"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              disabled: "",
              color: "primary",
              type: "border",
              "icon-pack": "feather",
              icon: "icon-search"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              radius: "",
              color: "primary",
              type: "border",
              "icon-pack": "feather",
              icon: "icon-search"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              radius: "",
              color: "warning",
              type: "filled",
              "icon-pack": "feather",
              icon: "icon-archive"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              radius: "",
              color: "success",
              type: "flat",
              "icon-pack": "feather",
              icon: "icon-camera"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              radius: "",
              color: "dark",
              type: "line",
              "icon-pack": "feather",
              icon: "icon-calendar"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              radius: "",
              color: "danger",
              type: "gradient",
              "icon-pack": "feather",
              icon: "icon-user-plus"
            }
          }),
          _vm._v(" "),
          _c("vs-button", {
            attrs: {
              disabled: "",
              radius: "",
              color: "primary",
              type: "border",
              "icon-pack": "feather",
              icon: "icon-search"
            }
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="border" icon-pack="feather" icon="icon-search"></vs-button>\n<vs-button color="warning" type="filled" icon-pack="feather" icon="icon-archive"></vs-button>\n<vs-button color="success" type="flat" icon-pack="feather" icon="icon-camera"></vs-button>\n<vs-button color="dark" type="line" icon-pack="feather" icon="icon-calendar"></vs-button>\n<vs-button color="danger" type="gradient" icon-pack="feather" icon="icon-user-plus"></vs-button>\n<vs-button disabled color="primary" type="border" icon-pack="feather" icon="icon-search"></vs-button>\n\n<vs-button radius color="primary" type="border" icon-pack="feather" icon="icon-search"></vs-button>\n<vs-button radius color="warning" type="filled" icon-pack="feather" icon="icon-archive"></vs-button>\n<vs-button radius color="success" type="flat" icon-pack="feather" icon="icon-camera"></vs-button>\n<vs-button radius color="dark" type="line" icon-pack="feather" icon="icon-calendar"></vs-button>\n<vs-button radius color="danger" type="gradient" icon-pack="feather" icon="icon-user-plus"></vs-button>\n<vs-button disabled radius color="primary" type="border" icon-pack="feather" icon="icon-search"></vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue?vue&type=template&id=a8372f8e&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue?vue&type=template&id=a8372f8e& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Line Down", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To add a type of button with edges we change the value of "),
        _c("code", [_vm._v("type")]),
        _vm._v(" by: "),
        _c("code", [_vm._v("line")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("span", [
            _vm._v(
              'you can change the position of the line up with the property line-position="top". You can also change the way the line appears on mouse hover with the property line-origin using the allowed values: '
            ),
            _c("strong", [_vm._v("left, center(default) or right")])
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { type: "line" } }, [_vm._v("Primary")]),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: { type: "line", "line-origin": "left", color: "success" }
            },
            [_vm._v("Success")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: { type: "line", "line-origin": "right", color: "danger" }
            },
            [_vm._v("Danger")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                type: "line",
                "line-position": "top",
                "line-origin": "left",
                color: "warning"
              }
            },
            [_vm._v("Warning")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                type: "line",
                "line-position": "top",
                "line-origin": "right",
                color: "dark"
              }
            },
            [_vm._v("Dark")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { type: "line", disabled: "" } }, [
            _vm._v("Disabled")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button type="line">Primary</vs-button>\n<vs-button type="line" line-origin="left" color="success">Success</vs-button>\n<vs-button type="line" line-origin="right" color="danger">Danger</vs-button>\n<vs-button type="line" line-position="top" line-origin="left" color="warning">Warning</vs-button>\n<vs-button type="line" line-position="top" line-origin="right" color="dark">Dark</vs-button>\n<vs-button type="line" disabled>Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonLink.vue?vue&type=template&id=e0635606&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonLink.vue?vue&type=template&id=e0635606& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Link", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can specify for "),
        _c("code", [_vm._v("window.location.href")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("span", [
            _vm._v("You can use the "),
            _c("code", [_vm._v("target")]),
            _vm._v(" property to window.open()")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c(
            "vs-button",
            {
              attrs: {
                color: "primary",
                type: "filled",
                href: "https://pixinvent.com/"
              }
            },
            [_vm._v("String literal")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "primary",
                type: "filled",
                href: { url: "https://pixinvent.com/" }
              }
            },
            [_vm._v("Object Path")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "primary",
                type: "filled",
                target: "",
                href: "https://pixinvent.com/"
              }
            },
            [_vm._v("Open New Tab")]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="filled" href="https://pixinvent.com/">String literal</vs-button>\n<vs-button color="primary" type="filled" :href="{url: \'https://pixinvent.com/\'}">Object Path</vs-button>\n<vs-button color="primary" type="filled" target href="https://pixinvent.com/">Open New Tab</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonRelief.vue?vue&type=template&id=617e3e54&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonRelief.vue?vue&type=template&id=617e3e54& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Relief", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To add a type of button with edges we change the value of "),
        _c("code", [_vm._v("type")]),
        _vm._v(" by: "),
        _c("code", [_vm._v("relief")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { type: "relief" } }, [_vm._v("Primary")]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "success", type: "relief" } }, [
            _vm._v("Success")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "danger", type: "relief" } }, [
            _vm._v("Danger")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "warning", type: "relief" } }, [
            _vm._v("warning")
          ]),
          _vm._v(" "),
          _c("vs-button", { attrs: { color: "dark", type: "relief" } }, [
            _vm._v("dark")
          ]),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { color: "rgb(187, 138, 200)", type: "relief" } },
            [_vm._v("Color")]
          ),
          _vm._v(" "),
          _c("vs-button", { attrs: { disabled: "", type: "relief" } }, [
            _vm._v("Disabled")
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button type="relief">Primary</vs-button>\n<vs-button color="success" type="relief">Success</vs-button>\n<vs-button color="danger" type="relief">Danger</vs-button>\n<vs-button color="warning" type="relief">warning</vs-button>\n<vs-button color="dark" type="relief">dark</vs-button>\n<vs-button color="rgb(187, 138, 200)" type="relief">Color</vs-button>\n<vs-button disabled type="relief">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonRouter.vue?vue&type=template&id=19a2ce0c&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonRouter.vue?vue&type=template&id=19a2ce0c& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Router", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can send a string or object to directive to. This directive wrap a $router.push() vue method, you can use all programmatic navigation on vue router."
        )
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c(
            "vs-button",
            {
              attrs: {
                color: "primary",
                type: "filled",
                to: "/components/list"
              }
            },
            [_vm._v("String literal")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "warning",
                type: "filled",
                to: { path: "/components/list" }
              }
            },
            [_vm._v("Object Path")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: { color: "success", type: "filled", to: { name: "todo" } }
            },
            [_vm._v("Named Router")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: {
                color: "dark",
                type: "filled",
                to: { path: "/pages/search", query: { q: "modern admin" } }
              }
            },
            [_vm._v("With Query")]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button color="primary" type="filled" to="/components/list">String literal</vs-button>\n<vs-button color="warning" type="filled" :to="{ path: \'/components/list\' }">Object Path</vs-button>\n<vs-button color="success" type="filled" :to="{ name: \'todo\'}">Named Router</vs-button>\n<vs-button color="dark"    type="filled" :to="{ path: \'/pages/search\', query: { q: \'modern admin\' } }">With Query</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonSize.vue?vue&type=template&id=7b1c2984&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonSize.vue?vue&type=template&id=7b1c2984& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Size", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To define the size of button the directive is used "),
        _c("code", [_vm._v("size")]),
        _vm._v(". there are three type of size: "),
        _c("code", [_vm._v("large")]),
        _vm._v(", "),
        _c("code", [_vm._v("default")]),
        _vm._v(", "),
        _c("code", [_vm._v("small")]),
        _vm._v(
          ". It is not important to specify the size when the button is of type "
        ),
        _c("code", [_vm._v("default")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c("vs-button", { attrs: { size: "large" } }, [_vm._v("Large")]),
          _vm._v(" "),
          _c("vs-button", [_vm._v("Default")]),
          _vm._v(" "),
          _c("vs-button", { attrs: { size: "small" } }, [_vm._v("Small")])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button size="large">Large</vs-button>\n<vs-button>Default</vs-button>\n<vs-button size="small">Small</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue?vue&type=template&id=72604143&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue?vue&type=template&id=72604143& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Text Color", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can change the font color of buttons, need only set the prop "
        ),
        _c("code", [_vm._v("text-color")]),
        _vm._v(" with your color")
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-alignment" },
        [
          _c(
            "vs-button",
            { attrs: { type: "border", "text-color": "#7367F0" } },
            [_vm._v("Primary")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { type: "border", "text-color": "#28C76F" } },
            [_vm._v("Success")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { type: "border", "text-color": "#EA5455" } },
            [_vm._v("Danger")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { type: "border", "text-color": "rgb(255,159,67)" } },
            [_vm._v("Warning")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              staticClass: "demo-text-dark",
              attrs: { type: "border", "text-color": "rgb(30,30,30)" }
            },
            [_vm._v("Dark")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { type: "border", "text-color": "tomato" } },
            [_vm._v("Color")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            { attrs: { disabled: "", "text-color": "rgb(0, 0, 0)" } },
            [_vm._v("Disabled")]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-button type="border" text-color="#7367F0">Primary</vs-button>\n<vs-button type="border" text-color="#28C76F">Success</vs-button>\n<vs-button type="border" text-color="#EA5455">Danger</vs-button>\n<vs-button type="border" text-color="rgb(255,159,67)">Warning</vs-button>\n<vs-button type="border" class="demo-text-dark" text-color="rgb(30,30,30)">Dark</vs-button>\n<vs-button type="border" text-color="tomato">Color</vs-button>\n<vs-button disabled text-color="rgb(0, 0, 0)">Disabled</vs-button>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/Button.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/Button.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Button_vue_vue_type_template_id_3c85a93a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button.vue?vue&type=template&id=3c85a93a& */ "./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=template&id=3c85a93a&");
/* harmony import */ var _Button_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Button_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Button_vue_vue_type_template_id_3c85a93a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Button_vue_vue_type_template_id_3c85a93a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/Button.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Button_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Button.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Button_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=template&id=3c85a93a&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=template&id=3c85a93a& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Button_vue_vue_type_template_id_3c85a93a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Button.vue?vue&type=template&id=3c85a93a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/Button.vue?vue&type=template&id=3c85a93a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Button_vue_vue_type_template_id_3c85a93a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Button_vue_vue_type_template_id_3c85a93a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonBorder.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonBorder.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonBorder_vue_vue_type_template_id_4f04816f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonBorder.vue?vue&type=template&id=4f04816f& */ "./resources/js/src/views/components/vuesax/button/ButtonBorder.vue?vue&type=template&id=4f04816f&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonBorder_vue_vue_type_template_id_4f04816f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonBorder_vue_vue_type_template_id_4f04816f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonBorder.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonBorder.vue?vue&type=template&id=4f04816f&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonBorder.vue?vue&type=template&id=4f04816f& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonBorder_vue_vue_type_template_id_4f04816f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonBorder.vue?vue&type=template&id=4f04816f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonBorder.vue?vue&type=template&id=4f04816f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonBorder_vue_vue_type_template_id_4f04816f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonBorder_vue_vue_type_template_id_4f04816f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonColor.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonColor.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonColor_vue_vue_type_template_id_437fe670___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonColor.vue?vue&type=template&id=437fe670& */ "./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=template&id=437fe670&");
/* harmony import */ var _ButtonColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ButtonColor.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ButtonColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ButtonColor_vue_vue_type_template_id_437fe670___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonColor_vue_vue_type_template_id_437fe670___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonColor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonColor.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=template&id=437fe670&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=template&id=437fe670& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonColor_vue_vue_type_template_id_437fe670___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonColor.vue?vue&type=template&id=437fe670& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonColor.vue?vue&type=template&id=437fe670&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonColor_vue_vue_type_template_id_437fe670___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonColor_vue_vue_type_template_id_437fe670___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonFilled.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonFilled.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonFilled_vue_vue_type_template_id_4495a0b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonFilled.vue?vue&type=template&id=4495a0b6& */ "./resources/js/src/views/components/vuesax/button/ButtonFilled.vue?vue&type=template&id=4495a0b6&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonFilled_vue_vue_type_template_id_4495a0b6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonFilled_vue_vue_type_template_id_4495a0b6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonFilled.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonFilled.vue?vue&type=template&id=4495a0b6&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonFilled.vue?vue&type=template&id=4495a0b6& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonFilled_vue_vue_type_template_id_4495a0b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonFilled.vue?vue&type=template&id=4495a0b6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonFilled.vue?vue&type=template&id=4495a0b6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonFilled_vue_vue_type_template_id_4495a0b6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonFilled_vue_vue_type_template_id_4495a0b6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonFlat.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonFlat.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonFlat_vue_vue_type_template_id_acec6608___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonFlat.vue?vue&type=template&id=acec6608& */ "./resources/js/src/views/components/vuesax/button/ButtonFlat.vue?vue&type=template&id=acec6608&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonFlat_vue_vue_type_template_id_acec6608___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonFlat_vue_vue_type_template_id_acec6608___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonFlat.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonFlat.vue?vue&type=template&id=acec6608&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonFlat.vue?vue&type=template&id=acec6608& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonFlat_vue_vue_type_template_id_acec6608___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonFlat.vue?vue&type=template&id=acec6608& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonFlat.vue?vue&type=template&id=acec6608&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonFlat_vue_vue_type_template_id_acec6608___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonFlat_vue_vue_type_template_id_acec6608___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonGradient.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonGradient.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonGradient_vue_vue_type_template_id_ae05389a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonGradient.vue?vue&type=template&id=ae05389a& */ "./resources/js/src/views/components/vuesax/button/ButtonGradient.vue?vue&type=template&id=ae05389a&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonGradient_vue_vue_type_template_id_ae05389a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonGradient_vue_vue_type_template_id_ae05389a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonGradient.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonGradient.vue?vue&type=template&id=ae05389a&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonGradient.vue?vue&type=template&id=ae05389a& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGradient_vue_vue_type_template_id_ae05389a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonGradient.vue?vue&type=template&id=ae05389a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonGradient.vue?vue&type=template&id=ae05389a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGradient_vue_vue_type_template_id_ae05389a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGradient_vue_vue_type_template_id_ae05389a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonIcon.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonIcon.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonIcon_vue_vue_type_template_id_1ca489fc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonIcon.vue?vue&type=template&id=1ca489fc& */ "./resources/js/src/views/components/vuesax/button/ButtonIcon.vue?vue&type=template&id=1ca489fc&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonIcon_vue_vue_type_template_id_1ca489fc___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonIcon_vue_vue_type_template_id_1ca489fc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonIcon.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonIcon.vue?vue&type=template&id=1ca489fc&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonIcon.vue?vue&type=template&id=1ca489fc& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonIcon_vue_vue_type_template_id_1ca489fc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonIcon.vue?vue&type=template&id=1ca489fc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonIcon.vue?vue&type=template&id=1ca489fc&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonIcon_vue_vue_type_template_id_1ca489fc___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonIcon_vue_vue_type_template_id_1ca489fc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonIconOnly_vue_vue_type_template_id_71c105c8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonIconOnly.vue?vue&type=template&id=71c105c8& */ "./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue?vue&type=template&id=71c105c8&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonIconOnly_vue_vue_type_template_id_71c105c8___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonIconOnly_vue_vue_type_template_id_71c105c8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue?vue&type=template&id=71c105c8&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue?vue&type=template&id=71c105c8& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonIconOnly_vue_vue_type_template_id_71c105c8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonIconOnly.vue?vue&type=template&id=71c105c8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonIconOnly.vue?vue&type=template&id=71c105c8&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonIconOnly_vue_vue_type_template_id_71c105c8___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonIconOnly_vue_vue_type_template_id_71c105c8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonLineDown_vue_vue_type_template_id_a8372f8e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonLineDown.vue?vue&type=template&id=a8372f8e& */ "./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue?vue&type=template&id=a8372f8e&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonLineDown_vue_vue_type_template_id_a8372f8e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonLineDown_vue_vue_type_template_id_a8372f8e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonLineDown.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue?vue&type=template&id=a8372f8e&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue?vue&type=template&id=a8372f8e& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonLineDown_vue_vue_type_template_id_a8372f8e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonLineDown.vue?vue&type=template&id=a8372f8e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonLineDown.vue?vue&type=template&id=a8372f8e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonLineDown_vue_vue_type_template_id_a8372f8e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonLineDown_vue_vue_type_template_id_a8372f8e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonLink.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonLink.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonLink_vue_vue_type_template_id_e0635606___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonLink.vue?vue&type=template&id=e0635606& */ "./resources/js/src/views/components/vuesax/button/ButtonLink.vue?vue&type=template&id=e0635606&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonLink_vue_vue_type_template_id_e0635606___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonLink_vue_vue_type_template_id_e0635606___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonLink.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonLink.vue?vue&type=template&id=e0635606&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonLink.vue?vue&type=template&id=e0635606& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonLink_vue_vue_type_template_id_e0635606___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonLink.vue?vue&type=template&id=e0635606& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonLink.vue?vue&type=template&id=e0635606&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonLink_vue_vue_type_template_id_e0635606___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonLink_vue_vue_type_template_id_e0635606___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonRelief.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonRelief.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonRelief_vue_vue_type_template_id_617e3e54___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonRelief.vue?vue&type=template&id=617e3e54& */ "./resources/js/src/views/components/vuesax/button/ButtonRelief.vue?vue&type=template&id=617e3e54&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonRelief_vue_vue_type_template_id_617e3e54___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonRelief_vue_vue_type_template_id_617e3e54___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonRelief.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonRelief.vue?vue&type=template&id=617e3e54&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonRelief.vue?vue&type=template&id=617e3e54& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonRelief_vue_vue_type_template_id_617e3e54___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonRelief.vue?vue&type=template&id=617e3e54& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonRelief.vue?vue&type=template&id=617e3e54&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonRelief_vue_vue_type_template_id_617e3e54___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonRelief_vue_vue_type_template_id_617e3e54___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonRouter.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonRouter.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonRouter_vue_vue_type_template_id_19a2ce0c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonRouter.vue?vue&type=template&id=19a2ce0c& */ "./resources/js/src/views/components/vuesax/button/ButtonRouter.vue?vue&type=template&id=19a2ce0c&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonRouter_vue_vue_type_template_id_19a2ce0c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonRouter_vue_vue_type_template_id_19a2ce0c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonRouter.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonRouter.vue?vue&type=template&id=19a2ce0c&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonRouter.vue?vue&type=template&id=19a2ce0c& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonRouter_vue_vue_type_template_id_19a2ce0c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonRouter.vue?vue&type=template&id=19a2ce0c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonRouter.vue?vue&type=template&id=19a2ce0c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonRouter_vue_vue_type_template_id_19a2ce0c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonRouter_vue_vue_type_template_id_19a2ce0c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonSize.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonSize.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonSize_vue_vue_type_template_id_7b1c2984___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonSize.vue?vue&type=template&id=7b1c2984& */ "./resources/js/src/views/components/vuesax/button/ButtonSize.vue?vue&type=template&id=7b1c2984&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonSize_vue_vue_type_template_id_7b1c2984___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonSize_vue_vue_type_template_id_7b1c2984___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonSize.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonSize.vue?vue&type=template&id=7b1c2984&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonSize.vue?vue&type=template&id=7b1c2984& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonSize_vue_vue_type_template_id_7b1c2984___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonSize.vue?vue&type=template&id=7b1c2984& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonSize.vue?vue&type=template&id=7b1c2984&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonSize_vue_vue_type_template_id_7b1c2984___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonSize_vue_vue_type_template_id_7b1c2984___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonTextColor_vue_vue_type_template_id_72604143___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonTextColor.vue?vue&type=template&id=72604143& */ "./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue?vue&type=template&id=72604143&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _ButtonTextColor_vue_vue_type_template_id_72604143___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonTextColor_vue_vue_type_template_id_72604143___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/button/ButtonTextColor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue?vue&type=template&id=72604143&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue?vue&type=template&id=72604143& ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonTextColor_vue_vue_type_template_id_72604143___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ButtonTextColor.vue?vue&type=template&id=72604143& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/button/ButtonTextColor.vue?vue&type=template&id=72604143&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonTextColor_vue_vue_type_template_id_72604143___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonTextColor_vue_vue_type_template_id_72604143___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);